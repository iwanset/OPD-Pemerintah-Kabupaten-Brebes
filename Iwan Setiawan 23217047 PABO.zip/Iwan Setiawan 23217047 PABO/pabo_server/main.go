package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

//main function
func main() {
	port := 8181

	router := mux.NewRouter()
	router.HandleFunc("/opd", GetOPDs).Methods("GET")
	router.HandleFunc("/opdprofilebyopd/{id}", GetOPDProfileByOPDID).Methods("GET")
	router.HandleFunc("/opd/{id}", GetOPD).Methods("GET")
	router.HandleFunc("/opd", CreateOPD).Methods("POST")
	router.HandleFunc("/createopdf/{id}", CreateOPDProfile).Methods("POST")
	router.HandleFunc("/opd/{id}", UpdateOPD).Methods("PUT")
	router.HandleFunc("/opd/{id}", DeleteOPD).Methods("DELETE")
	router.HandleFunc("/opdprofile/{id}", GetOPDTopProfile).Methods("GET")
	router.HandleFunc("/childopdprofile/{id}", GetChildOPDProfile).Methods("GET")

	log.Printf("Server starting on port %v\n", port)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%v", port), router))
}

//Struct opd
type opdData struct {
	OPDID        string
	NamaOPD string
	Singkatan  string
	Lat      float32
	Lng   float32
	Jumlah string
}

//Struct opd
type opdProfilData struct {
	ProfilID       string
	OPDID_fk        string
	Nama string
	ParentID  string
	Jumlah  string
}

type msgResponse struct {
	Status  string
	Message string
}

//Connection Database
func ConnDB() (*sql.DB, error) {

	//access database
	//Note : adjust your opd and password access. for this code, we use opd : root, password : password
	db, err := sql.Open("mysql", "root:@tcp(localhost:3306)/wservices")

	if err != nil {
		return nil, err
	}
	if err = db.Ping(); err != nil {
		return nil, err
	}

	return db, nil
}

//GetAllOPD
func GetOPDs(w http.ResponseWriter, r *http.Request) {
	//var myOPD opdData
					var(
			opd opdData
			opds []opdData
			)
		// get connection database
		db, err := ConnDB()
		if err != nil {
			log.Panic(err)
		}

	// run query to get data all opd
	rows, err := db.Query("select OPDID,NamaOPD,Singkatan,Lat,Lng from opd")
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	defer db.Close()

	// looping over the rows to get data each row
	for rows.Next() {
		//Read the columns in each row into variables
		err := rows.Scan(&opd.OPDID, &opd.NamaOPD, &opd.Singkatan, &opd.Lat, &opd.Lng)
		opds = append(opds, opd)
		if err != nil {
			log.Fatal(err)
		}
	}
	//encode to json format and send as  response
	json.NewEncoder(w).Encode(opds)	
}
//GET Profile OPD by OPDID
func GetOPDProfileByOPDID(w http.ResponseWriter, r *http.Request) {
	
	
		//var myOPD opdData
						var(
				opdprofil opdProfilData
				opdprofils []opdProfilData
				)
		// get connection database
		db, err := ConnDB()
		if err != nil {
			log.Panic(err)
		}
	// get id from request http
		params := mux.Vars(r)
		var OPDID = params["id"]
		
		// run query to get data all opd
		rows, err := db.Query("select ProfilID,OPDID_fk, Nama, (SELECT COUNT(b.ProfilID) FROM opd_profil b WHERE b.ParentID = a.ProfilID ) as Jumlah from opd_profil a WHERE OPDID_fk = ?", OPDID)
		if err != nil {
			log.Fatal(err)
		}
		defer rows.Close()
	
		// looping over the rows to get data each row
	
		for rows.Next() {
			//Read the columns in each row into variables
			err := rows.Scan(&opdprofil.ProfilID, &opdprofil.OPDID_fk, &opdprofil.Nama, &opdprofil.Jumlah)
			opdprofils = append(opdprofils, opdprofil)
			if err != nil {
				log.Fatal(err)
			}
	
			//encode to json format and send as  response
	
			
		}
		json.NewEncoder(w).Encode(opdprofils)
	
	}

//Get Specific OPD with id
func GetOPD(w http.ResponseWriter, r *http.Request) {

	var myOPD opdData

	// get connection database
	db, err := ConnDB()
	if err != nil {
		log.Panic(err)
	}

	// get id from request http
	params := mux.Vars(r)
	var OPDID = params["id"]

	// run query to get data opd with ID is params["id"]
	err = db.QueryRow("select OPDID,NamaOPD,Singkatan,Lat,Lng, (SELECT COUNT(b.ProfilID) FROM opd_profil b WHERE b.OPDID_fk = a.OPDID) as Jumlah from opd a where OPDID = ?", OPDID).Scan(&myOPD.OPDID, &myOPD.NamaOPD, &myOPD.Singkatan, &myOPD.Lat, &myOPD.Lng, &myOPD.Jumlah)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	//encode to json format and send as  response
	json.NewEncoder(w).Encode(&myOPD)

}

//Get Specific OPD Profile with id
func GetOPDTopProfile(w http.ResponseWriter, r *http.Request) {

	var myProfilOPD opdProfilData

	// get connection database
	db, err := ConnDB()
	if err != nil {
		log.Panic(err)
	}

	// get id from request http
	params := mux.Vars(r)
	var OPDID = params["id"]

	// run query to get data opd with ID is params["id"]
	err = db.QueryRow("select (SELECT COUNT(b.ProfilID) FROM opd_profil b WHERE b.ProfilID = a.ProfilID) as Jumlah, ProfilID, OPDID_fk,Nama,ParentID from opd_profil a where ParentID = 0 AND OPDID_fk = ?", OPDID).Scan(&myProfilOPD.Jumlah,&myProfilOPD.ProfilID,&myProfilOPD.OPDID_fk, &myProfilOPD.Nama, &myProfilOPD.ParentID)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	//encode to json format and send as  response
	json.NewEncoder(w).Encode(&myProfilOPD)

}

func GetChildOPDProfile(w http.ResponseWriter, r *http.Request) {


	//var myOPD opdData
					var(
			opdprofil opdProfilData
			opdprofils []opdProfilData
			)
	// get connection database
	db, err := ConnDB()
	if err != nil {
		log.Panic(err)
	}
// get id from request http
	params := mux.Vars(r)
	var OPDID = params["id"]
	
	// run query to get data all opd
	rows, err := db.Query("select ProfilID,Nama, (SELECT COUNT(b.ProfilID) FROM opd_profil b WHERE b.ParentID = a.ProfilID ) as Jumlah from opd_profil a WHERE ParentID= ?", OPDID)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()

	// looping over the rows to get data each row

	for rows.Next() {
		//Read the columns in each row into variables
		err := rows.Scan(&opdprofil.ProfilID, &opdprofil.Nama, &opdprofil.Jumlah)
		opdprofils = append(opdprofils, opdprofil)
		if err != nil {
			log.Fatal(err)
		}

		//encode to json format and send as  response

		
	}
	json.NewEncoder(w).Encode(opdprofils)

}

//Create OPD
func CreateOPD(w http.ResponseWriter, r *http.Request) {
	var myOPD opdData
	var msgR msgResponse
	// get connection database
	db, err := ConnDB()
	if err != nil {
		log.Panic(err)
	}

	//decode data from response body
	decoder := json.NewDecoder(r.Body)
	err = decoder.Decode(&myOPD)
	if err != nil {
		panic(err)
	}
	defer r.Body.Close()

	//prepare query to insert data
	stmt, err := db.Prepare("INSERT INTO opd (OPDID,NamaOPD,Singkatan,Lat,Lng)VALUES(?,?,?,?,?);")
	if err != nil {
		log.Fatal(err)
	}

	//execute with parameter data
	_, err = stmt.Exec(&myOPD.OPDID, &myOPD.NamaOPD, &myOPD.Singkatan, &myOPD.Lat, &myOPD.Lng)
	if err != nil {
		//log.Panic(err)
		msgR = msgResponse{Status: "Error", Message: err.Error()}
	} else {
		msgR = msgResponse{Status: "Success"}
	}

	//encode to json format and send status as  response
	json.NewEncoder(w).Encode(msgR)

}

//Create Profile OPD
func CreateOPDProfile(w http.ResponseWriter, r *http.Request) {
	var myOPDProfile opdProfilData
	var msgR msgResponse
	// get connection database
	db, err := ConnDB()
	if err != nil {
		log.Panic(err)
	}

	//decode data from response body
	decoder := json.NewDecoder(r.Body)
	err = decoder.Decode(&myOPDProfile)
	if err != nil {
		panic(err)
	}
	defer r.Body.Close()

	//prepare query to insert data
	stmt, err := db.Prepare("INSERT INTO opd_profil (OPDID_fk,Nama,ParentID)VALUES(?,?,?);")
	if err != nil {
		log.Fatal(err)
	}

	//execute with parameter data
	_, err = stmt.Exec(&myOPDProfile.OPDID_fk,&myOPDProfile.Nama,&myOPDProfile.ParentID)
	if err != nil {
		//log.Panic(err)
		msgR = msgResponse{Status: "Error", Message: err.Error()}
	} else {
		msgR = msgResponse{Status: "Success"}
	}

	//encode to json format and send status as  response
	json.NewEncoder(w).Encode(msgR)

}

//Delete OPD
func DeleteOPD(w http.ResponseWriter, r *http.Request) {

	var msgR msgResponse
	// get connection database
	db, err := ConnDB()
	if err != nil {
		log.Panic(err)
	}

	// get id from request http
	params := mux.Vars(r)
	var OPDID = params["id"]

	//prepare query to delete data
	stmt, err := db.Prepare("DELETE FROM opd where OPDID=?;")
	if err != nil {
		log.Fatal(err)
	}

	//execute with parameter data
	res, err := stmt.Exec(&OPDID)
	if err != nil {
		//log.Panic(err)
		msgR = msgResponse{Status: "Error", Message: err.Error()}
	}

	rowCount, err := res.RowsAffected()
	if err != nil {
		log.Fatal(err)
	}

	//encode to json format and send status as  response
	if rowCount > 0 {
		msgR = msgResponse{Status: "Success"}
	} else {
		msgR = msgResponse{Status: "Error", Message: "Not Found Data with OPDID " + OPDID}
	}

	json.NewEncoder(w).Encode(msgR)

}

//Update OPD
func UpdateOPD(w http.ResponseWriter, r *http.Request) {
	var myOPD opdData
	var msgR msgResponse

	// get connection database
	db, err := ConnDB()
	if err != nil {
		log.Panic(err)
	}

	// get id from request http
	params := mux.Vars(r)
	var OPDID = params["id"]

	//decode data from response body
	decoder := json.NewDecoder(r.Body)
	err = decoder.Decode(&myOPD)
	if err != nil {
		panic(err)
	}
	defer r.Body.Close()

	//prepare query to update data
	stmt, err := db.Prepare("UPDATE opd SET OPDID=?,NamaOPD=?,Singkatan=?,Lat=?,Lng=? where OPDID=?;")
	if err != nil {
		log.Fatal(err)
	}

	//execute with parameter data
	res, err := stmt.Exec(&myOPD.OPDID, &myOPD.NamaOPD, &myOPD.Singkatan, &myOPD.Lat, &myOPD.Lng, &OPDID)
	if err != nil {
		//log.Panic(err)
		msgR = msgResponse{Status: "Error", Message: err.Error()}
	}

	rowCount, err := res.RowsAffected()
	if err != nil {
		log.Fatal(err)
	}

	//encode to json format and send status as  response
	if rowCount > 0 {
		msgR = msgResponse{Status: "Success"}
	} else {
		msgR = msgResponse{Status: "Error", Message: "Not Found Data with OPDID " + OPDID}
	}

	//encode to json format and send status as  response
	json.NewEncoder(w).Encode(msgR)

}
