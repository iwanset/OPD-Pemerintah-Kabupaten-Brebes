<?php require_once('libs/libs.inc.php');

# LIST OPD
$smarty->assign('opd',$opd->opd_list());

# DETAIL OPD
if($_GET['id'])
{
	$id = $_GET['id'];
	$opd_detail = $opd->opd_detail($id);
	$smarty->assign('opd_detail',$opd_detail);
	
	if($opd_detail['Jumlah']>0)
	{
		$opd_profil = $opd->top_opd_profil($id);
		$smarty->assign('opd_profil',$opd_profil);
	}
}
$smarty->assign('opd_func',$opd);
$smarty->assign('loadmap','map.html');
$smarty->display('index.html');

?>