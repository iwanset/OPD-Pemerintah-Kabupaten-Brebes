<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>OPD Pemerintah Kabupaten Brebes</title>
</head>

<body>
<?php
	
	function get_child($parentid)
	{
		
		$json_string = file_get_contents("http://localhost:8181/childopdprofile/".$parentid);
		$opd_child= json_decode($json_string, true);
		$jml = count($opd_child);
		# print_r($opd_child);
		if($jml>0){
			echo "<ul>";
			for($i=0;$i<$jml;$i++)
			{
				echo"<li>".$opd_child[$i]['Nama']."</li>";
				
				$jml2 = $opd_child[$i]['Jumlah'];
				if($jml2>0) get_child($opd_child[$i]['ProfilID']);
			}

			echo "</ul>";
		}
	}


$json_string = file_get_contents("http://localhost:8181/opd");
$opd= json_decode($json_string, true);
	
if($_GET['id'])
{
	$json_string = file_get_contents("http://localhost:8181/opd/".$_GET['id']);
	$opd_detail= json_decode($json_string, true);
	//print_r($opd_detail);
	
	if($opd_detail['Jumlah']>0)
	{
		$json_string2 = file_get_contents("http://localhost:8181/opdprofile/".$_GET['id']);
		$opd_profile= json_decode($json_string2, true);
		//print_r($opd_profile);
	}
	
}
?>
<h1>OPD Pemerintah Kabupaten Brebes</h1>
   <select name="opid" onChange="document.location.replace('index.php?id='+this.value)"> 
      <option value="">Pilih Nama OPD</option>   <?php for($i=0;$i<COUNT($opd);$i++)	{ ?>
    
        <option value="<?php echo $opd[$i]['OPDID']; ?>" <?php if($_GET['id']==$opd[$i]['OPDID']) echo "selected"; ?>><?php echo $opd[$i]['NamaOPD']; ?></option>
        
    <?php }?>
    </select>
    
  <?php if($opd_detail['NamaOPD']){?>  
   <h3> Susunan Organisasi <?php echo $opd_detail['NamaOPD']; ?>, terdiri dari :</h3>
   <?php if($opd_profile['Nama']){?>
   <ul><li><?php echo $opd_profile['Nama'];?>
   
   </li><?php get_child($opd_profile['ProfilID'])?></ul>
   <?php }else echo "Belum ada data"; ?>
   
<!--<table border="1" cellpadding="10">
    <thead><tr><th>OPD</th><th>Singkatan</th></tr></thead>
    <tbody><?php for($i=0;$i<COUNT($opd);$i++)	{ ?>
        <tr>
            <td><?php echo $opd[$i]['NamaOPD']; ?></td>
			<td><?php echo $opd[$i]['Singkatan']; ?></td>
        </tr>
    <?php }?>
    </tbody>
</table>-->
<?php }else{ echo"<br>Silakan pilih profil OPD yang anda cari";}?>
</body>
</html>