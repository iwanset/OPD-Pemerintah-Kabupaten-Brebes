<html>
  <head>
    <title>Tambah Profil OPD</title>
	
	<!-- include css file here-->
    <link rel="stylesheet" href="css/submit_javascript.css"/>
	
	<!-- include javascript file here-->
    <script src="js/submit_javascript.js"></script> 
   
  </head>
  
  <body>
   <?php
	  print_r($_POST);
	  
	  $json_string = file_get_contents("http://localhost:8181/opd");
	  $opd= json_decode($json_string, true);
	  
	  if($_POST['OPDID_fk'])
	  {
		  # TAMPILKAN SEMUA PROFIL SKPD
		  $json_string = file_get_contents("http://localhost:8181/opdprofilebyopd/".$_POST['OPDID_fk']);
	  	  $opd_profile= json_decode($json_string, true);
		  //print($json_string);
		  
	  }
	  
	  # SIMPAN DATA PROFIL OPD
	  if($_POST['action']=='Kirim')
	  {
		  	$data = $_POST;      
		  	$data_string = json_encode($data);   

			$ch = curl_init('http://localhost:8181/createopdf/'.$_POST['OPDID_fk']);                                                                      
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
				'Content-Type: application/json',                                                                                
				'Content-Length: ' . strlen($data_string))                                                                       
			);                                                                                                                   

			curl_exec($ch); 
		  	
		  	if($_POST['tetap']=='1')				
			{
				
			}
				else{ header("location:create.php");
		  	exit();
					}
		  
	  }
	  
	  ?>
    <div class="container">
	  <div class="main">
	    <form action="#" method="post" name="form_name" id="form_id" class="form_class" >
		  <h2>Tambah Profil OPD</h2><hr/>
		   <label>Pilih OPD :</label><br/>
		     <select name="OPDID_fk" onChange="submit_by_id()"> 
      <option value="">Pilih Nama OPD</option>   <?php for($i=0;$i<COUNT($opd);$i++)	{ ?>
    
        <option value="<?php echo $opd[$i]['OPDID']; ?>" <?php if($_POST['OPDID_fk']==$opd[$i]['OPDID']) echo "selected"; ?>><?php echo $opd[$i]['NamaOPD']; ?></option>
        
    <?php }?>
    </select><br/>	
		  <label>Nama Bag / Bid / Subbag / subbid / Seksi :</label><br/>
		  <input type="text" name="Nama" id="Nama" placeholder="Nama" /><br/>	

		  <label>Induk :</label><br/>
		  <select name="ParentID" > 
      <option value="0">Pilih Induk</option>   
      <?php for($i=0;$i<COUNT($opd_profile);$i++)	{ ?>
    
        <option value="<?php echo $opd_profile[$i]['ProfilID']; ?>" <?php if($_POST['ParentID']){
			if($_POST['ParentID']==$opd_profile[$i]['ParentID']) echo "selected"; }else{}?>>
			<?php echo $opd_profile[$i]['Nama'];?></option> 
		<?php }?>
    </select><br/>
       	  
		  <input type="submit" name="action" value="Kirim"/> <input type="checkbox" value="1" <?php if($_POST[tetap]=='1'){echo "checked";}?> name="tetap" /> Tetap di form setelah input
		  		 
	    </form>
	  </div> 
	  <!-- Div Fugo is advertisement div-->
	  <div class="fugo">
		  <a href="http://www.formget.com/app/"><img src="images/formGetadv-1.jpg" /></a>
	  </div>
	</div>  
  </body>

</html>  