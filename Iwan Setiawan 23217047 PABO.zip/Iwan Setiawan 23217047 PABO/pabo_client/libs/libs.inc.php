<?php // chaining of method calls
require_once('smarty/Smarty.class.php');
require_once('opd.class.php');
$location = dirname (__FILE__);

$opd = new opd();

$smarty = new Smarty;
$smarty->setTemplateDir($location.'/templates')
       ->setCompileDir($location.'/templates_c')
	->setConfigDir($location.'/configs')
       ->setCacheDir($location.'/cache');


?>