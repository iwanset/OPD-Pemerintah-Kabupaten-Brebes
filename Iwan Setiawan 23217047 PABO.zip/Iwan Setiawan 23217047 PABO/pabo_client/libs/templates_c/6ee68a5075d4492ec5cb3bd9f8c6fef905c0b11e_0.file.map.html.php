<?php
/* Smarty version 3.1.30, created on 2017-11-16 11:44:55
  from "E:\WEB_EXP\pbo-project\libs\templates\map.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a0d7a378350e7_45226182',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6ee68a5075d4492ec5cb3bd9f8c6fef905c0b11e' => 
    array (
      0 => 'E:\\WEB_EXP\\pbo-project\\libs\\templates\\map.html',
      1 => 1510832685,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a0d7a378350e7_45226182 (Smarty_Internal_Template $_smarty_tpl) {
?>

  
    <div id="map"></div>
     

    <?php echo '<script'; ?>
>
      var customLabel = {
        restaurant: {
          label: 'R'
        },
        bar: {
          label: 'B'
        }
      };
		
		

        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(-6.8650757864858285, 109.0389633178711),
          zoom: 12
        });
        var infoWindow = new google.maps.InfoWindow;
			var opid = <?php echo $_GET['id'];?>
;
/*google.maps.event.addListener(map, 'click', function( event ){
  alert( "Latitude: "+event.latLng.lat()+" "+", longitude: "+event.latLng.lng() ); 
});*/
          // Change this depending on the name of your PHP or XML file
          downloadUrl('http://localhost/pbo-project/markers.php', function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var name = markerElem.getAttribute('name');
              var address = markerElem.getAttribute('address');
              var type = markerElem.getAttribute('type');
			 // var link = <a href=?id=id>name</a>;
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = name
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));

              var text = document.createElement('text');
              text.textContent = address
			  //text.textContent = link
              infowincontent.appendChild(text);
              var icon = customLabel[type] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label
              });
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    <?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD4pBoKXITD01f3eExWSj1y2PAAD0UyZBk &callback=initMap">
    <?php echo '</script'; ?>
>


<?php }
}
