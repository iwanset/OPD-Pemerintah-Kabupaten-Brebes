<?php
/* Smarty version 3.1.30, created on 2017-11-15 07:36:19
  from "E:\WEB_EXP\pbo-project\smarty\demo\templates\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a0bee7379dc97_70458342',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '998462cf0a004f9593919beb5f646bbb31436480' => 
    array (
      0 => 'E:\\WEB_EXP\\pbo-project\\smarty\\demo\\templates\\footer.tpl',
      1 => 1470545208,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a0bee7379dc97_70458342 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '237615a0bee73797733_23805340';
?>
</BODY>
</HTML>
<?php }
}
