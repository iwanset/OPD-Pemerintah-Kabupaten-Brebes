<?php
/* Smarty version 3.1.30, created on 2017-11-15 07:54:57
  from "E:\WEB_EXP\pbo-project\libs\templates\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a0bf2d19316f8_27650383',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c4af49f846b6d86e4f9e0786abe27120c2071c7f' => 
    array (
      0 => 'E:\\WEB_EXP\\pbo-project\\libs\\templates\\header.tpl',
      1 => 1470545208,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a0bf2d19316f8_27650383 (Smarty_Internal_Template $_smarty_tpl) {
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['Name']->value;?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
