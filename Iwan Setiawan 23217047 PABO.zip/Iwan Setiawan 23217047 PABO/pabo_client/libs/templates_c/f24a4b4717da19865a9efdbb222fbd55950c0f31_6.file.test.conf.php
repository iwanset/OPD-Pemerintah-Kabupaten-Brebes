<?php /* Smarty version 3.1.30, created on 2017-11-15 07:36:19
         compiled from "E:\WEB_EXP\pbo-project\smarty\demo\configs\test.conf" */ ?>
<?php
/* Smarty version 3.1.30, created on 2017-11-15 07:36:19
  from "E:\WEB_EXP\pbo-project\smarty\demo\configs\test.conf" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a0bee732d9e92_35210315',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f24a4b4717da19865a9efdbb222fbd55950c0f31' => 
    array (
      0 => 'E:\\WEB_EXP\\pbo-project\\smarty\\demo\\configs\\test.conf',
      1 => 1470545208,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a0bee732d9e92_35210315 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
