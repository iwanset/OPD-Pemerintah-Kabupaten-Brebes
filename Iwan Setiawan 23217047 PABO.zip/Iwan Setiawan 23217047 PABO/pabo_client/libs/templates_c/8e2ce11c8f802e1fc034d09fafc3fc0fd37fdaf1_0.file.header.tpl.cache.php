<?php
/* Smarty version 3.1.30, created on 2017-11-15 07:36:19
  from "E:\WEB_EXP\pbo-project\smarty\demo\templates\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a0bee734fc470_95952130',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '8e2ce11c8f802e1fc034d09fafc3fc0fd37fdaf1' => 
    array (
      0 => 'E:\\WEB_EXP\\pbo-project\\smarty\\demo\\templates\\header.tpl',
      1 => 1470545208,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a0bee734fc470_95952130 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '81845a0bee734dce12_91101842';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:81845a0bee734dce12_91101842%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:81845a0bee734dce12_91101842%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
