<?php /* Smarty version 3.1.30, created on 2017-11-16 00:37:10
         compiled from "E:\WEB_EXP\pbo-project\libs\configs\test.conf" */ ?>
<?php
/* Smarty version 3.1.30, created on 2017-11-16 00:37:10
  from "E:\WEB_EXP\pbo-project\libs\configs\test.conf" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a0cddb6a64d63_86082251',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bee686062d95e9b7c85c4f639b00f83bcba96cea' => 
    array (
      0 => 'E:\\WEB_EXP\\pbo-project\\libs\\configs\\test.conf',
      1 => 1510792575,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a0cddb6a64d63_86082251 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'OPD - Pemerintah Kabupaten Brebes',
    'menu_title' => 'Daftar OPD',
    'copyright' => 'Pemerintah Kabupaten Brebes',
  ),
));
}
}
