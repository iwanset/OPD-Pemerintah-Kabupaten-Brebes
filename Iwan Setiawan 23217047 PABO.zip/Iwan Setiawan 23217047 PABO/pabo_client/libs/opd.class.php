<?php
class opd{
	function opd ()
	{
		
	}
	function opd_list()
	{
		$json_string = file_get_contents("http://localhost:8181/opd");
		$opd= json_decode($json_string, true);
		return $opd;
	}
	function parseToXML($htmlStr)
	{
		$xmlStr=str_replace('<','&lt;',$htmlStr);
		$xmlStr=str_replace('>','&gt;',$xmlStr);
		$xmlStr=str_replace('"','&quot;',$xmlStr);
		$xmlStr=str_replace("'",'&#39;',$xmlStr);
		$xmlStr=str_replace("&",'&amp;',$xmlStr);
		return $xmlStr;	
	}
	function markers($id='')
	{
		if($id) $result = $this->opd_detail($id);
		else $result = $this->opd_list();
		//print_r($result);
		header("Content-type: text/xml");

		// Start XML file, echo parent node
		echo '<markers>';

		// Iterate through the rows, printing XML nodes for each
		for ($i=0;$i<count($result);$i++){
		  // Add to XML document node
		  echo '<marker ';
		  echo 'id="' . $result[$i]['OPDID'] . '" ';
		  echo 'name="' . $this->parseToXML($result[$i]['NamaOPD']) . '" ';
		  echo 'address="' . $this->parseToXML($result[$i]['address']) . '" ';
		  echo 'lat="' . $result[$i]['Lat'] . '" ';
		  echo 'lng="' . $result[$i]['Lng'] . '" ';
		  echo 'type="' . $result[$i]['type'] . '" ';
		  echo '/>';
		}

		// End XML file
		echo '</markers>';
	}
	
	function opd_detail($id)
	{
		$json_string = file_get_contents("http://localhost:8181/opd/".$id);
		$opd_detail= json_decode($json_string, true);
		return $opd_detail;
	}
	function top_opd_profil($id)
	{
		$json_string2 = file_get_contents("http://localhost:8181/opdprofile/".$id);
		$opd_profile= json_decode($json_string2, true);
		return $opd_profile;
	}
	function child_opd_profil($pid)
	{
		$json_string = file_get_contents("http://localhost:8181/childopdprofile/".$pid);
		$opd_child= json_decode($json_string, true);
		$jml = count($opd_child);

		if($jml>0){
			echo "<ul>";
			for($i=0;$i<$jml;$i++)
			{
				echo"<li>".$opd_child[$i]['Nama']."</li>";
				
				$jml2 = $opd_child[$i]['Jumlah'];
				if($jml2>0) $this->child_opd_profil($opd_child[$i]['ProfilID']);
			}

			echo "</ul>";
		}
	}
}